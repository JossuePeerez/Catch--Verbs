import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 *la clase de tipo credito carga una imagen ya hecha con los nombres de los creadores
 *se pone un boton para que pueda regresar al menu.
 */
public class Credito extends World
{
    //atributos de la clase
    private Boton bot;
    GreenfootSound sonido3 = new GreenfootSound("menu.mp3");
    /**
     * Constructor for objects of class Records.
     * da las dimensiones de la pantalla.
     * crea el boton de regreso
     * y da un pequeño sonido si da click en el boton.
     */
    public Credito()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(600, 400, 1); 
        bot=new Boton();
        addObject(bot,400,300);
       if(!sonido3.isPlaying()) sonido3.play();
    }
    
    /**
     * el metodo act hace que se reproduzca el sonido de inicio y da 
     * la opcion de regresar a menu apretando el boton
     */
    public void act()
    {
           if(Greenfoot.getMouseInfo()!=null){ 
            if(Greenfoot.getMouseInfo().getButton()==1 && Greenfoot.getMouseInfo().getActor() == bot)
            {
                // press.play();
                Greenfoot.delay(30);
               // fondo.stop();
                sonido3.stop();
                Greenfoot.setWorld(new Menu());
            }
        }
    }
}
