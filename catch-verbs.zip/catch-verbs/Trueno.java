import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * la clase trueno se utiliza como parte del escenario y es un tipo de proyectil 
 * de tipo villano 
 */
public class Trueno extends Villano2
{
    /**
     * el constructor manda llamar a las funciones de:
     * caen()
     * chocapou()
     */
    public void act() 
    {
        // Add your action code here.
        caen();
    }    
    
    /**
     * se le da la posicion en donde se encuentra con los metodos getx y gety
     * y pregunta si ha llegado al limite inferior y se da el caso desaparece
     * el objeto y que no se quede acumulado en la parte inferior del escenario
     */
    public void caen()
    {
      setLocation(getX(),getY()+2);
        //Greenfoot.delay(3);
        if(isAtEdge())
           getWorld().removeObject(this);
    }

}
