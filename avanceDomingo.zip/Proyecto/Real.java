import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Real here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Real extends Words
{
    
    public Real(String text,int rot)
    {
        super(text, rot);
    }
    /**
     * Act - do whatever the Real wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        super.act();
    }
}
