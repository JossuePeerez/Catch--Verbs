import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.*;

/**
 * la clase nivel 1 crea un universo con sus propios actores.
 * las palabras que aparecen a continuacion son las basicas que 
 * corresponden a este nivel.
 * le da las posiciones iniciales a cada actor y hace que se 
 * pueda crear el juego.
 */
public class Nivel1 extends Nivel
{
    //tributos de la clase
    private Popu popu;
    private Boladefuego bola;
    private Villano1 malo1;
 
    private Words word;
    private int r,rand;
    private int nivel=1;
    private String[] Awords = {"ask", "borrow", "brush", 
        "call", "check", "clean", "climb", "cook", "cover", 
        "cross","cross","dream","dress","earn","end","enter","enjoy",
        "explain","fail"};
        
    private String[] FWords = {"asq", "borou", "bush", 
        "calli", "chek", "cleen", "claimb", "coc", "cober", 
        "ros","cros","druim","dres","irn","ennd","inter","enyoi",
        "explanada","faill"};
    private Menu menu;
    private int puntos;
    public UserInfo myInfo = UserInfo.getMyInfo();
        
    /**
     * Constructor for objects of class MyWorld.
     * inicializa los valores del universo numero 1 
     */
    public Nivel1()
    {    
        popu = new Popu();
        addObject(popu ,250,580);
        
        malo1 = new Villano1();
        addObject(malo1,450,50);
        myInfo.setScore(0);
    }
   
    /**
     * se le da los puntos de cada nivel a los scores
     *se manda llamar al metodo nivel 1 para que este cree la logica del juego.
     */
    public void act()
    {
       
        if(nivel==1)
        nivel1();
        
        puntos= popu.getPuntos()+ myInfo.getScore();
        showText("Puntaje: " + puntos, 50, 40);

        if(popu.getPuntaje()>50)
          {
             myInfo.setScore(puntos);
             Greenfoot.setWorld( new Nivel2());
          } 
         
    }

    /**
     * el metodo nivel 1 crea los diferentes tipos de palabras en el universo
     * les da valores random a la rotacion para que aparezcan de forma diferente
     * agrega un villano de forma diferente para cada nivel.
     */
    public void nivel1()
    { 
        setBackground("tumblr_mqgwoj3lU71spluqvo3_1280.png");
        if(Greenfoot.getRandomNumber(1000)<=20)
            {
                rand = Greenfoot.getRandomNumber(90);
                rand = rand+45;    
                if(Greenfoot.getRandomNumber(2)==0) //When Real
                {
                    r=Greenfoot.getRandomNumber(Awords.length);
                    word=new Real(Awords[r],rand);
                    addObject(word,(Greenfoot.getRandomNumber(400))+20,10); 
                } 
                else  //When fake
                {
                    r=Greenfoot.getRandomNumber(FWords.length);
                    word=new Fake(FWords[r],rand);
                    addObject(word,(Greenfoot.getRandomNumber(400))+20,10); 
                }
            }
            
        if(Greenfoot.getRandomNumber(1000)<=3)
        {
            bola = new Boladefuego(15); 
            addObject(bola,450,40);

        }
 
    }

    
    
}
