import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 *clase que se administra los tres niveles
 *guarda los records del jugador 
 */
public class Nivel extends World
{
    //atributos
    public UserInfo myInfo = UserInfo.getMyInfo();
    
    /**
     * Constructor for objects of class Niveles.
     * 
     */
    public Nivel()
    {    
        
        super(500, 600, 1); 
    }
    
    /**
     * manda llamar a los metodos que se encargan de guardar la informacion de los usuarios.
     */
    
    public void setRecord(int puntos)
    {
        if (UserInfo.isStorageAvailable()) {
            UserInfo myInfo = UserInfo.getMyInfo();
            if (puntos > myInfo.getScore()) {
                myInfo.setScore(puntos);
                myInfo.store();
            }
        }
    }
}
