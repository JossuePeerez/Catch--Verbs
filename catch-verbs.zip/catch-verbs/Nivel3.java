import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.*;

/**
 * la clase nivel 3 crea un universo con sus propios actores.
 * las palabras que aparecen a continuacion son phrasal verbs y le da la oportunidad
 * al personaje de jugar con ellas y juntarlas.
 * corresponden a este nivel.
 * le da las posiciones iniciales a cada actor y hace que se 
 * pueda crear el juego.
 */
public class Nivel3 extends Nivel
{
    //private Trueno trueno;
    private Popu3 popu3;
    private Burbuja bur;
    private Gary malo3;
    
    private SimpleTimer timer;
    
    private Words word;
    private int r,rand;
    private int nivel=2;
   
    private String[] Awords = {"cut", "break","catch", "come", "dress", 
                               "eat", "fall", "get", "go", "hold", "hang",
                                "speak","take","stop","remove","bring","mention",
                               "catch", "reach", "return", "get", "leave", "become"
                            ,"grow","look", "try", "make"};
        
    private String[] FWords = {"off", "up", "down", "apart", "front", "in",
                                "out" , "back", "on" ,"to" };
    private int puntos;
    public UserInfo myInfo = UserInfo.getMyInfo();
    GreenfootSound sonido3 = new GreenfootSound("menu.mp3");
   
        
    /**
     * Constructor for objects of class MyWorld.
     * inicializa los valores iniciales de los actores.
     * 
     */
    public Nivel3()
    {    

        myInfo.setScore(100);
        popu3 = new Popu3();
        addObject(popu3 ,250,480);
        
        malo3 = new Gary();
        addObject(malo3,250,50);
        
        
        timer = new SimpleTimer();
        timer.mark();
    }
   
   /**
    * el metodo act manda llamar al metodo nivel3 que se encarga de la logica del juego.
    */
    public void act()
    {
       
        setBackground("rompecabezas-de-doki-para_501d49c4be7f7_img.jpg");
        
        puntos= popu3.getPuntos()+ myInfo.getScore();
        showText("Puntaje: " + puntos, 50, 40);
        
       GreenfootSound sonido3 = new GreenfootSound("menu.mp3");
        
        if(timer.millisElapsed() > 60000)
          {
              myInfo.setScore(puntos);
              showText("GAME OVER ",250,250);
              Greenfoot.delay(100);
              if(!sonido3.isPlaying())sonido3.stop();
              //Greenfoot.setWorld( new Menu());
              
          }
          
        if(Greenfoot.getRandomNumber(1000)<=20)
            {
                rand = Greenfoot.getRandomNumber(90);
                rand = rand+45;    
                if(Greenfoot.getRandomNumber(2)==0) //When Real
                {
                    r=Greenfoot.getRandomNumber(Awords.length);
                    word=new Real(Awords[r],rand);
                    addObject(word,(Greenfoot.getRandomNumber(400))+20,10); 
                } 
                else  //When fake
                {
                    r=Greenfoot.getRandomNumber(FWords.length);
                    word=new Fake(FWords[r],rand);
                    addObject(word,(Greenfoot.getRandomNumber(400))+20,10); 
                }
            }
            
        if(Greenfoot.getRandomNumber(1000)<=3)
        { 
            addObject(new Burbuja(),25,50);
        }
        
    }
}