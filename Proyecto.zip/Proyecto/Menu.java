import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Menu here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Menu extends World
{
    private Play play;
   /* private Ayuda ayuda;
    private Record rec;
    private Credito cred;*/
    /**
     * Constructor for objects of class Menu.
     * 
     */
    public Menu()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(500, 600, 1);   
        play=new Play();
        addObject(play,309,178);
    }
    public void act()
    {    
         //fondo.playLoop();
        if(Greenfoot.getMouseInfo()!=null){ 
            if(Greenfoot.getMouseInfo().getButton()==1 && Greenfoot.getMouseInfo().getActor() == play)
            {
               // press.play();
                Greenfoot.delay(30);
               // fondo.stop();
                Greenfoot.setWorld(new Game());
            }

        }

        /*if(Greenfoot.getMouseInfo()!=null){
            if(Greenfoot.getMouseInfo().getButton()==1 && Greenfoot.getMouseInfo().getActor()==ayuda)
            {
               // press.play();
                Greenfoot.delay(5);
               // fondo.stop();
                Greenfoot.setWorld(new RunAyuda());
            }
        }

        if(Greenfoot.getMouseInfo()!=null){
            if(Greenfoot.getMouseInfo().getButton()==1 && Greenfoot.getMouseInfo().getActor()==rec)
            {
               // press.play();
                Greenfoot.delay(5);
               // fondo.stop();
                Greenfoot.setWorld(new RunRecord());
            }
        }

        if(Greenfoot.getMouseInfo()!=null){
            if(Greenfoot.getMouseInfo().getButton()==1 && Greenfoot.getMouseInfo().getActor()==cred)
            {
                //press.play();
                Greenfoot.delay(5);
                //fondo.stop();
                Greenfoot.setWorld(new RunCredito());
            }
        }*/
    }
}
