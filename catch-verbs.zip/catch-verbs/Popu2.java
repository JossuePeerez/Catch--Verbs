import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Popu2 here.
 * *popu2 es un tipo de heroe tipo 2
 * se encarga de aparecer en el segundo nivel y comer palabras
 * se mueve de izquierda a derecha y de arriba hacia abajp con las teclas
 */
public class Popu2 extends Heroe
{
    public static final int UP=0;
    public static final int DOWN=1;
    public static final int LEFT=2;
    public static final int RIGHT=3;
    private int puntos  =   0;
    GreenfootSound sonido1 = new GreenfootSound("real.wav");
    GreenfootSound sonido2 = new GreenfootSound("fake.wav");
    GreenfootSound sonido3 = new GreenfootSound("1.wav");
    
    /**
     * se mueve de forma distinta que los demas popu
     * come es un metodo abstracto de la clase padre.
     * cada uno de los tipos de popu comen de forma diferente.
     */
    public void act() 
    {
       muevePou();
       come();
    }    

    /**
     * la funcion se encarga de mover a popu dentro del escenario a 
     * todas las direcciones, manda la direccion a setDireccion 
     * para que este pueda obtener y decidir a donde se mueve
     */

    public void muevePou()
    {
        // Add your action code here.
        if(Greenfoot.isKeyDown("up"))
        {
         setDireccion(UP);
        }
        if(Greenfoot.isKeyDown("down"))
        {
         setDireccion(DOWN);
        }
        if(Greenfoot.isKeyDown("left"))
        {
         setDireccion(LEFT);
        }
        if(Greenfoot.isKeyDown("right"))
        {
         setDireccion(RIGHT);
        }
    }
    
    /**
     * @param int direccion para que llegue una direccion
     * con seleccion de casos mueve a popu dentro del escenario
     * y no le permite salir de el.
     */
    public void setDireccion(int direccion)
    {
        
        switch(direccion)
        {
              case UP:
              setLocation(getX(),getY() -3);
              break;
            
              case DOWN:
              setLocation(getX(),getY() +3);
              break;
              
              case LEFT:
              setLocation(getX()-3,getY());
              break;
              
              case RIGHT:
              setRotation(0);
              setLocation(getX()+3,getY());
              break;
          
        }
    
    }
    
    /**
    * funcion que regresa los puntos hechos por el personaje
    * @return puntos obtenidos.
    */ 
   public int getPuntos()
   {
    return puntos;
   }
   
    /**
    *dependiendo de que come el personaje 
    * se crea una variable de tipo actor para que 
    * pregunte si es de tipo fake, real , trueno.
    * villano 2 entra en esta funcion para que no se lo pueda comer.
    * en caso de que sea de alguna de estas clases le resta puntos o 
    * la elimina del escenario.
    */
   public void come()
   {
       Actor actor = getOneObjectAtOffset(2, 1, Words.class);
       Actor actor2 = getOneObjectAtOffset(2, 1, Villano.class);
      
      
        if(actor != null) 
        {
            setImage("pou_panda2 (2).png");
            
            if( actor instanceof Fake) 
            {
                if(puntos > 0 && puntos > 10) puntos -= 10;
                else if(puntos > 0 && puntos < 10) puntos = 0;
                if(!sonido2.isPlaying()) sonido2.play();
            } 
            else if( actor instanceof Real) 
            {
                puntos += 10;
                if(!sonido1.isPlaying()) sonido1.play();

            }
 
        
            getWorld().removeObject(actor);
            
        } else {
           setImage("pou_panda.png");
        }
        
        if(actor2 != null) 
        {
            if( actor2 instanceof Trueno)
            {
                if(puntos > 0 && puntos > 3) puntos -= 3;
                else if(puntos > 0 && puntos < 3) puntos = 0;
                
                if(!sonido3.isPlaying()) sonido3.play();
                getWorld().removeObject(actor2);
                
            }
           
            
            if( actor2 instanceof Villano2)
            {
                if(puntos > 0 && puntos > 3) puntos -= 3;
                else if(puntos > 0 && puntos < 3) puntos = 0;
                
                if(!sonido3.isPlaying()) sonido3.play();
            }
     
        }
        
        super.setPuntaje(puntos);
  }
  

}