import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import greenfoot.GreenfootSound.*;
/**
 * Write a description of class Mierdin here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Popu extends Heroe

{
    private String nombre;
    private float puntaje;
    private int vidas;
    
    /**
     * Act - do whatever the Mierdin wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
   public Popu()
   {
      nombre = " ";
      puntaje= 0;
      vidas = 3;
    }
   
       public float getPuntaje()
    {
        return puntaje;
    }
    public void act() 
    {
        super.CheckKeys();
        come();
   }
   
   public void come()
   {
      Actor actor = getOneObjectAtOffset(4, 2, Words.class);
      
        if(actor != null) 
        {
            setImage("images/pou_comiendo.png");
            Greenfoot.playSound("sounds/eatfruit.wav");
            
            if( actor instanceof Fake) 
            {
                //System.out.printf("Fake\n");
            } else if( actor instanceof Real) 
            {
                //System.out.printf("Real\n");
                puntaje = +100;
            }
        }
        if(actor == null)
        {
            setImage("images/pue_c.png");
            getWorld().removeObject(actor);
        } 
   }
}
