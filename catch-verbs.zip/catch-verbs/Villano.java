import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 *la clase abstracta villano colecta a los tipo de villano en una clasificacion
 *de tipo villano. 
 *es de tipo abstracto porque nunca se instancia como tal 
 *solo los junta.
 */
public abstract class Villano extends Actor
{
   
}
