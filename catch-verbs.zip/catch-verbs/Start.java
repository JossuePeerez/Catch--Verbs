import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * la clase start sirve para instanciar objetos de tipo boton(imagen) y ponerlos 
 *sobre cada pantalla del juego y que este redirija hacia otra parte del juego.
 *es utilizado en la clase menu
 *redirecciona a la pantalla de inicio del juego.
 *
 */
public class Start extends Boton
{
    /**
     * Act - do whatever the Start wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
    }    
}
