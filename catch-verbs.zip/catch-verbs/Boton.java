import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 *la clase boton sirve para instanciar objetos de tipo boton(imagen) y ponerlos 
 *sobre cada pantalla del juego y que este regrese al menu principal
 *es utilizado en la clase menu
 *contiene dentro de la clase una imagen de tipo boton
 */
public class Boton extends Actor
{
    /**
     * Act - do whatever the Boton wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
    }    
}
