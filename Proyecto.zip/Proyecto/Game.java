import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
/**
 * Write a description of class MyWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Game extends World
{
    private Popu popu;
    private Words word;
    private int r,rand;
    private String[] Awords = {"ask", "borrow", "brush", 
        "call", "check", "clean", "climb", "cook", "cover", 
        "cross","cross","dream","dress","earn","end","enter","enjoy",
        "explain","fail"};
    /**
     * Constructor for objects of class MyWorld.
     * 
     */
    public Game()
    {    
        super(500, 600, 1); 
        popu=new Popu();
       
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        addObject(popu,250,580);
    }
    public Popu getPopu()
    {
        return popu;
    }
    public void act()
    {
        if(Greenfoot.getRandomNumber(1000)<=20)
        {
            rand = Greenfoot.getRandomNumber(90);
            rand = rand+45;
            r=Greenfoot.getRandomNumber(Awords.length);
            word=new Words(Awords[r],rand);
            addObject(word,(Greenfoot.getRandomNumber(400))+20,10);      
        }
    }
}
