import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * la clase nube se utiliza como objeto de tipo escenario que se muestra en el nivel 2
 * las posiciones donde sera instanciado se ejecutan dentro del nivel donde se crean.
 */
public class Nube extends Villano2
{
    /**
     * la imagen de tipo nube se le brinda directamente de los archivos de la 
     * carpeta de proyecto con el metodo que es heredado de la clase actor 
     * setImage();
     */
    public void act() 
    {
        // Add your action code here.
    }    
}
