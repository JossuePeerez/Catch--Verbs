import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * la clase villano2 hace que se creen objetos que se mueven dentro del escenario
 * el villano de tipo2 se mueve de un lado a otro simulando que lanza truenos.
 */
public class Villano2 extends Villano
{
   
    /**
     * se obtiene el mundo de donde se manda llamar el villano y pregunta si se ha 
     * llegado al limite de escenario en posicion al ancho.
     * pregunta las posiciones dentro del mundo con getWidth
     */
    public void act() 
    {
        move(2);
        World m = getWorld();
        
        if(getX()>m.getWidth()-5)
        {
          m.removeObject(this);
          m.addObject(this,20,50);
        }
       
    }
}