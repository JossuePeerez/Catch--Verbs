import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * clase que crea un nuevo universo de tipo ayuda con una imagen ya establecida
 */
public class Ayuda extends World
{
    private Boton bot;
    GreenfootSound sonido3 = new GreenfootSound("menu.mp3");
    
    /**
     * da las dimensiones del universo
     * crea un boton de retorno
     * le da un sonido de fondo
     */
    public Ayuda()
    {
        // Create a new world with 600x500 cells with a cell size of 1x1 pixels.
        super(600, 500, 1); 
        bot=new Boton();
        addObject(bot,400,400);
        if(!sonido3.isPlaying()) sonido3.play();
    }
    
    /**
     * si aprieta el boton lo redirecciona a ayuda
     * le da un sonido de fondo
     */
    public void act()
    {
            
        if(Greenfoot.getMouseInfo()!=null){ 
            if(Greenfoot.getMouseInfo().getButton()==1 && Greenfoot.getMouseInfo().getActor() == bot)
            { Greenfoot.delay(30);
                sonido3.stop();
                Greenfoot.setWorld(new Menu());
            }
        }
    }
}
