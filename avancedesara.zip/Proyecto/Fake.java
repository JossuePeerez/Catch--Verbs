import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Fake here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Fake extends Words
{
    
    public Fake(String text,int rot)
    {
        super(text, rot);
    }
    
    /**
     * Act - do whatever the Fake wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        super.act();
    }    
}
