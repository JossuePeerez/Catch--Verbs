import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.Color;
/**
 * Write a description of class Palabras here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Words extends Actor
{
    /**
     * Act - do whatever the Palabras wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    private int ran;
    private int n=2;
    private Popu c;
    private int x;
    private int y;
    private int rota;
    private Game  mundo;
    
    public Words(String text,int rot)
    {
        GreenfootImage gi= new greenfoot.GreenfootImage(100,30);
        gi.drawString(text,2,20);
        setImage(gi);
        rota=rot;
        setRotation(rota); //De 45 a 135
    } 
    public void act() 
    {
        // Add your action code here.
        x=getX();
        y=getY();
        mundo = (Game)getWorld();
        
        verifica();
        move(n);
         
        //tambalea();
    }    
    
    /**

     */
    public void verifica()
    {
        if(x<10)
        {
            rota=rota*-1;
            setRotation(rota);
            n=n*-1;
        }
        else if(x>490)
        {
            rota=rota*-1;
            setRotation(rota);
            n=n*-1;
        }
        
        /*ame mundo = (Game)getWorld();
        Popu c = mundo.getPopu();   
        ran=Greenfoot.getRandomNumber(600);
        int x;
        x=getX();
        */
        /*if(isTouching(Popu.class))
        {
           // c.aumentapuntos(10);
            //mundo.removeObject(this);
        }*/

        if(y>590)
        { 
            mundo.removeObject(this);
        }
    }
}
