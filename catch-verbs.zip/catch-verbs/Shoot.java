import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * la clase Shoot es la que se encarga de crear objetos de tipo disparo
 * este tipo de clase solo puede ser utilizada por heroe de tipo 3
 * POPU3
 */
public class Shoot extends Popu3
{
   //ATRIBUTOS
    int speedShoot=6;//Velocidad de disparo
    int posicion;//posicion de la bala.
    /**
     * el constructor
     * recibe como parametro la direccion de donde se mandara el disparo.
     */
    
    public Shoot(int direccion)
    {
        posicion=direccion;
    }
    
    /**
     * se selecciona a que posicion del escenario se movera el disparo.
     * tambien si llega a los limites del escenario desaparece el disparo.
     */
    public void act() 
    {
        // Add your action code here.
        switch(posicion)
        {
           case 0:
                setLocation(getX(),getY()-speedShoot);
                break;
           case 1:
                setLocation(getX(),getY()+speedShoot);
                break;
           case 2:
                setLocation(getX()+speedShoot,getY());
                break;
           case 3:
                setLocation(getX()-speedShoot,getY());
                break;
         
        }
        if(getX()>getWorld().getWidth()-5||(getX()<=5))
        {
            getWorld().removeObject(this);
        }else{
        if(getY()>getWorld().getHeight()-5||(getY()<=5))
        {
            getWorld().removeObject(this);
        }
        }
    }
    
}