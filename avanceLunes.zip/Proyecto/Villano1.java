import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Villano1 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Villano1 extends Villano
{
    /**
     * Act - do whatever the Villano1 wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
        {
          if(Greenfoot.getRandomNumber(1000)<=150)
        {
            setImage("images/villano_1.2.png");
        }
        else
        {
            setImage("images/villano_1.1.png");
        }
        
    }   
}
   