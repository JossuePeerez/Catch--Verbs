import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 *clase Villano de tipo uno, al permanecer en una sola posicion solo necesita ser instanciado
 * en la posicion donde se encuentra.
 * se le da una imagen del tipo del villano1
 */
public class Villano1 extends Villano
{
    /**
     * el metodo act solo le brinda la imagen al tipo de jugador uno.
     */
    public void act() 
    {
      
            setImage("images/villano_1.1.png");
    }   
}
   