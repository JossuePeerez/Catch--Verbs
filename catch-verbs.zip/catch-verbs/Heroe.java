import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Heroe here.
 * la clase heroe es de tipo abstracta porque no se 
 * instancia nada de ella.
 * los diferentes popu que existen en el universo 
 * son administrados por esta clase.
 */
public abstract class Heroe extends Actor
{
    //atributos
    private int x;
    private int y;
    private int vel=3;
    private int puntaje;
    
    /**
     * act contiene el metodo checkKeys.
     */
    public void act() 
    {
        CheckKeys();
    }    
    
    /**
     * este metodo se encarga del movimiento mas basico de popu
     * el cual es moverse de un lado a otro en el escenario
     * este metodo es heredado a todas sus clases hijas 
     * aunque el unico tipo de popu que utiliza el metodo es
     */
    public void CheckKeys()
    {
        x=getX();
        y=getY();
        if (Greenfoot.isKeyDown("Left"))
        {
            if(x>0)
                setLocation(x-vel,y);
        }
        else if (Greenfoot.isKeyDown("Right"))
        {
            if(x<500)
                setLocation(x+vel,y);
        }
    }
    
    /**
     * metodo abtracto que es heredado a todas sus clases para que estas 
     * lo implementen de forma forzada.
     * cada tipo de popu come de forma distinta y gracias a este metodo 
     * les permite que cada una de las clases hijas reescriban el metodo
     * de acuerdo a sus necesidades.
     */
    public abstract void come();
   
    /**
     * funcion que retorna el puntaje dl heroe 
     * @return puntaje
     */
    public int getPuntaje()
    {
        return puntaje;
    }
    
    /**
     * funcion que permite modificar el puntaje 
     * para que pueda ser modificado por lo niveles 
     * o por los diferentes tipos de personajes.
     */
    public void setPuntaje(int puntaje) 
    {                                             
       this.puntaje = puntaje;
    }    
           
}
