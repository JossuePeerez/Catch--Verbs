import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * la clase Gary es un tipo de villano3 
 * al crear una imagen de tipo GifImage le brinda las propiedades del un gif 
 * y hace el movimiento de este .
 * la clase GifImage se importa para poder usar este tipo de imagen.
 */
public class Gary extends Villano
{
    GifImage mygif = new GifImage("large.gif");
    /**
     * se le da la imagen de tipo gif 
     * anteriormente establecida
     * gracias a esto permite que la imagen siga su movimiento natural.
     */
    public void act() 
    {
        // Add your action code here.
        setImage(mygif.getCurrentImage());
    }    
}
