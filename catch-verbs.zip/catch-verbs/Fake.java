import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * la clase fake solo sirve para instanciar objetos de tipo palabra incorrecta de ella.
 */
public class Fake extends Words
{
     /**
     * le llega como parametro a la clase el texto que va a convertir y la rotacion 
     * que se le dara.
     * utiliza el metodo de la clase padre "act"
     */
    public Fake(String text,int rot)
    {
        super(text, rot);
    }
    
    /**
     * manda a llamar el metodo de su clase padre act
     */
    public void act() 
    {
        super.act();
    }    
    
   
    
    
}
