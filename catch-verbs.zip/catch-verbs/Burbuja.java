import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * la clase burbuja funje como tipo de villano numero 3
 * se utiliza para que rebote dentro del escenario y se pueda eliminar unicamente 
 * con los proyectiles del heroe tipo 3
 */
public class Burbuja extends Gary
{
    /**
     * el metodo act solo manda llamar a los metodos que estan establecidos.
     */
    public void act() 
    {
        revotaBurbuja();
        explotaBurbuja();
    }
    
    /**
     * el metodo explotaburbuja pregunta si se ha tocado un objeto de la clase shoot
     * del tipo heroe 3 y si se da el caso en que se intersecten 
     * elimina el objeto de la clase.
     */
    public void explotaBurbuja()
    {
      World m = getWorld();
      Actor act = getOneIntersectingObject(Shoot.class);
      if(act!=null)
      {
        getWorld().removeObject(this);
      }
    }
    
    /**
     * revota burbuja es un metodo que simula el rebote de la burbuja dentro del escenario
     * a diferencia de los otros proyectiles que lanzan los otros villanos
     * burbuja es el unico que puede ser eliminado por el jugador con un disparo
     */
    public void revotaBurbuja()
    {
         move(2);
            World m = getWorld();
            if(getX()>m.getWidth() -5|| getX()<=5)
            {
              turn(180);
              if(Greenfoot.getRandomNumber(100)<90)
              {
                 turn(Greenfoot.getRandomNumber(90-45));
              }
            }
            
            if(getY()>m.getHeight() -5|| getY()<=5)
            {
              turn(180);
              if(Greenfoot.getRandomNumber(100)<90)
              {
                 turn(Greenfoot.getRandomNumber(90-45));
              }
            }
    }
}
