import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.*;

/**
 *la clase nivel 2 crea un universo con sus propios actores.
 * las palabras que aparecen a continuacion son mas que las del nivel anterior y 
 * corresponden a este nivel.
 * le da las posiciones iniciales a cada actor y hace que se 
 * pueda crear el juego.
 */
public class Nivel2 extends Nivel
{
    private Popu2 popu2;
    private Popu popu;
    private Trueno rayo;
    private Villano2 malo1;
    private Words word;
    private int r,rand;
    private int nivel=2;
    
    private String[] Awords = {"ask", "borrow", "brush", 
        "call", "check", "clean", "climb", "cook", "cover", 
        "cross","cross","dream","dress","earn","end","enter","enjoy",
        "explain","fail",
        
        "be","become","begin","break","choose", "come",
        "feel", "forget", "sleep", "send",
        "sing", "sell", "speak", "meet", "ride","tell", "win","steal",
        "swim", "think", "wake", "wear", "find", "fly", "grow", "hear",
        "hurt", "have", "make", "teach", "see", "let", "write"};
        
    private String[] FWords = {"asq", "borou", "bush", 
        "calli", "chek", "cleen", "claimb", "cocacola", "cober", 
        "ros","rop","druim","dres","irn","ennd","inter","enyoi",
        "explan","faill",
    
        "bi","becom","begn","breaq","chose", "comer",
        "fel", "forgt", "slep", "senf",
        "sng", "sel", "speaq", "meed", "rid","tll", "wln","stel",
        "swi", "thinq", "waqe", "weae", "fynd", "fli", "grw", "her",
        "hur", "hae", "maw", "teah", "se", "lut", "writee"};

    private int puntos;
    public UserInfo myInfo = UserInfo.getMyInfo();
    
    /**
     * Constructor for objects of class MyWorld.
     * inicializa los valores de los personajes al iniciar el juego.
     * 
     */
    public Nivel2()
    {    
        myInfo.setScore(60);
    
        //actores dentro del universo
        popu2 = new Popu2();
        addObject(popu2 ,250,280);
        
        malo1 = new Villano2();
        addObject(malo1,0,40);
        
        //objetos que se utilizan como utilria
        addObject(new Nube(),0,60);
        addObject(new Nube(),50,60);
        addObject(new Nube(),130,60);
        addObject(new Nube(),230,60);
        addObject(new Nube(),330,60);
        addObject(new Nube(),430,60);
        addObject(new Nube(),490,60);
        addObject(new Nube(),80,60);
        addObject(new Nube(),180,60);
        addObject(new Nube(),280,60);
        addObject(new Nube(),360,60);
    }
   
    /**
     * el metodo act se encarga de mandar llamar al nivel 2
     * y gurda los scores que se hicieron durante el juego.
     */
    public void act()
    {
      
        if(nivel==2)
        nivel2();
        
        puntos= popu2.getPuntos()+ myInfo.getScore();
        showText("Puntaje: " + puntos, 50, 40);
        
        if(popu2.getPuntaje()>30)
          {
             myInfo.setScore(puntos);
             Greenfoot.setWorld( new Nivel3());
          } 
          
    }
    
    /**
     * el metodo nivel 2 se encarga de crear las palabras con las rotaciones
     * dadas.
     * instancia las palabras correctas e incorrectas 
     */
    public void nivel2()
    {
   
        setBackground("castle.png");
        
        //Greenfoot.setSpeed(100);
        if(Greenfoot.getRandomNumber(1000)<=20)
            {
                rand = Greenfoot.getRandomNumber(90);
                rand = rand+45;    
                if(Greenfoot.getRandomNumber(2)==0) //When Real
                {
                    r=Greenfoot.getRandomNumber(Awords.length);
                    word=new Real(Awords[r],rand);
                    addObject(word,(Greenfoot.getRandomNumber(400))+20,10); 
                } 
                else  //When fake
                {
                    r=Greenfoot.getRandomNumber(FWords.length);
                    word=new Fake(FWords[r],rand);
                    addObject(word,(Greenfoot.getRandomNumber(400))+20,10); 
                }
            }
            
        if(Greenfoot.getRandomNumber(1000)<=3)
        { 
            addObject(new Trueno(),10,20);
        }
        if(Greenfoot.getRandomNumber(1000)<=3)
        { 
            addObject(new Trueno(),200,20);
        }
          if(Greenfoot.getRandomNumber(1000)<=3)
        { 
            addObject(new Trueno(),400,20);
        }
       
    }
}