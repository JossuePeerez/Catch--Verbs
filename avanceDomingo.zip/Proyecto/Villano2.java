import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Villano2 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Villano2 extends Villano
{
   
    /**
     * Act - do whatever the Villano2 wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        move(2);
        World m = getWorld();
        
        if(getX()>m.getWidth()-5)
        {
          m.removeObject(this);
          m.addObject(this,20,50);
        }
       
    }
}