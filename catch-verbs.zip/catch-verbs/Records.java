import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * clase que muestra los records
 */
public class Records extends World
{
     private Boton bot;
     private ScoreBoard scores;
     
      GreenfootSound sonido3 = new GreenfootSound("menu.mp3");
    /**
     * tamaño del universo
     * crear un boton de regreso
     * y un nuevo objeto de tipo scores para ir agregando el puntaje
     */
    public Records()
    {    
       
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(600, 400, 1); 
        bot=new Boton();
        scores = new ScoreBoard(600,300);
        addObject(bot,100,50);
        if(!sonido3.isPlaying()) sonido3.play();
        
        addObject(scores,300,250);
        
        
    }
    
    /**
     * si aprieta el boton, lo redirecciona a records
     * le da un nuevo mundo de tipo menu si decide regresar
     */
    public void act()
    {
           if(Greenfoot.getMouseInfo()!=null){ 
            if(Greenfoot.getMouseInfo().getButton()==1 && Greenfoot.getMouseInfo().getActor() == bot)
            {
                Greenfoot.delay(30);
                sonido3.stop();
                Greenfoot.setWorld(new Menu());
            }
        }
    }
}
