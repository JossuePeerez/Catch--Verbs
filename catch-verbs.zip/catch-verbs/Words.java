import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import greenfoot.Color;
import java.awt.Font;
import java.awt.Graphics;
import javax.swing.JPanel;

/**
 * la clase words es la encargada de administrar como van apareciendo 
 * los verbos correctos e incorrectos en pantalla.
 * Convierte las cadenas(palabras) en objetos para poder distinguirlas 
 * entre clases
 * @author saray y josue 
 * @version (version final)
 */
public class Words extends Actor
{
    //atributos de la clase 
    private int ran;//variable para random
    private int n=2;
    private int x;// pos x
    private int y;//pos y
    private int rota;// rotacion
    
    /**
     * el metodo act es el encargado de mandar llamar a las funciones
     * mientras se siga ejecutando.
     */
    public void act() 
    {
        // Add your action code here.
        x=getX();
        y=getY();
        getWorld();
        verifica();
        move(n);
    }    
   
    /**
     * el metodo words convierte las cadenas en objetos
     * cuando se crea una umagen del texto que le llega de cada nivel
     * se le da el fondo para que muestre transparencia y color.
     */
    public Words(String text,int rot)
    {
        GreenfootImage textImage = new GreenfootImage(text, 30, new Color(102, 0, 102), new Color(0, 0, 0, 0));
        setImage(textImage);
        rota=rot;
        setRotation(rota); //rotacion decidida en cada nivel.
    } 
      
    /**
     * el metodo "verifica" se encarga de que las palabras no sean arrastradas fuera del escenario. 
     * que cuando lleguen al limite del escenario, desaparezcan.
     */
    public void verifica()
    {
        if(x<10)
        {
            rota=rota*-1;
            setRotation(rota);
            n=n*-1;
        }
        else if(x>490)
        {
            rota=rota*-1;
            setRotation(rota);
            n=n*-1;
        }
   
        if(y>590)
        { 
            getWorld().removeObject(this);
        }
    }
}
