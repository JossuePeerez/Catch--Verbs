import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * la clase bola de fuego, crea un proyectil de tipo fuego que se encarga
 * de dañar al heroe si lo toca.
 */
public class Boladefuego extends Villano1
{   
    //atributos de la clase.
    private int n=2;
    private int x;
    private int y;
    private int rota;
    private Nivel1  mundo; 
    

    /**
     * se le brinda el universo donde sera instanciado,se le da la posicion 
     * donde se pondra y se manda llamar a los otros metodos
     */
    public void act() 
    {
        // Add your action code here.
       x=getX();
       y=getY();
       mundo = (Nivel1)getWorld();
       choque();
       move(n);
       
    }    
     
   /**
    * al constructor de la clase se le da la rotacion que respetara 
    * para el movimiento dentro del universo.
    */
   public Boladefuego(int rot)
    {
        rota=rot;
        setRotation(rota);
    }
    
    /**
     * si choca dentro de las dimensiones del universo, respeta la rotacion que entra 
     * dentro de la clase y lo hace rebotar.
     */
    public void choque()
    {
        if(x<10)
           {
            rota=rota*-1;
            setRotation(rota);
            n=n*-1;
           }
          else if(x>490)
           {
            rota=rota*-1;
            setRotation(rota);
            n=n*-1;
           }
        //remueve el objeto si llego al limite del universo.
        if(y>590)
        { 
            mundo.removeObject(this);
        }
    }
}
