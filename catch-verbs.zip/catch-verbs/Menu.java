import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Menu here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Menu extends World
{
    private Start start;
    private help ayuda;
    private Rec cred;
    private Autors autor;
    private int nivel=1;
    
    private String nombre;
    private Heroe jug;
    GreenfootSound sonido2 = new GreenfootSound("CrystalBell.aiff");
    GreenfootSound sonido3 = new GreenfootSound("menu.mp3");

    //private Credito cred;
    /**
     * Clase que redirecciona con el boton hacia donde se va a dirigir
     * inicio, ayuda, records o credito
     */
    public Menu()
    {    
        // Create a new world with 690x600 cells with a cell size of 1x1 pixels.
        super(690, 600, 1);   
        
        start=new Start();
        addObject(start,400,370);
        ayuda=new help();
        addObject(ayuda,480,370);
        cred=new Rec();
        addObject(cred,400,450); 
        autor=new Autors();
        addObject(autor,480,450);
        
    }
    
    /**
     * en act pregunta si ha oprimido algun boton y si es cierto lo redirecciona dandole un nuevo universo
     * le da musica de fondo
     */
    public void act()
    {    
        
       
        if(!sonido3.isPlaying()) sonido3.play();
        if(Greenfoot.getMouseInfo()!=null){ 
            if(Greenfoot.getMouseInfo().getButton()==1 && Greenfoot.getMouseInfo().getActor() == start)
            {
                    Greenfoot.delay(3);
                    if(!sonido2.isPlaying()) sonido2.play();
                   Greenfoot.setWorld( new Nivel1());
             }
                
         }

        if(Greenfoot.getMouseInfo()!=null){
            if(Greenfoot.getMouseInfo().getButton()==1 && Greenfoot.getMouseInfo().getActor() == ayuda)
            {
               if(!sonido2.isPlaying()) sonido2.play();
                Greenfoot.delay(5);
                sonido3.stop();
                Greenfoot.setWorld( new Ayuda());
            }
        }

        if(Greenfoot.getMouseInfo()!=null){
            if(Greenfoot.getMouseInfo().getButton()==1 && Greenfoot.getMouseInfo().getActor() == cred)
            {
                if(!sonido2.isPlaying()) sonido2.play();
                Greenfoot.delay(5);
                sonido3.stop();
                Greenfoot.setWorld( new Records());
            }
        }

        if(Greenfoot.getMouseInfo()!=null){
            if(Greenfoot.getMouseInfo().getButton()==1 && Greenfoot.getMouseInfo().getActor()==autor)
            {
                if(!sonido2.isPlaying()) sonido2.play();
                Greenfoot.delay(5);
                sonido3.stop();
                Greenfoot.setWorld(new Credito());
            }
        }
    }
}
