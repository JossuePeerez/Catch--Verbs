import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import greenfoot.GreenfootSound.*;
/**
 * popu es un tipo de heroe tipo 1
 * se encarga de aparecer en el primer nivel y comer palabras
 * se mueve de izquierda a derecha con las teclas.
 */
public class Popu extends Heroe

{
    private int puntos  =   0;//puntos para acumular por cada que coma
    //sonidos que aparecen si comer de forma correcta o incorrecta.
    //Tambien si lo daña algun proyectil del villano 
    GreenfootSound sonido1 = new GreenfootSound("real.wav");
    GreenfootSound sonido2 = new GreenfootSound("fake.wav");
    GreenfootSound sonido3 = new GreenfootSound("1.wav");
    
    /**
     *checa el movimiento en el escenario heredado de su clase padre.
     *come es un metodo abstracto de la clase padre.
     * cada uno de los tipos de popu comen de forma diferente.
     */
    public void act() 
    {
        super.CheckKeys();
        come();
   }
   
   /**
    * funcion que regresa los puntos hechos por el personaje
    * @return puntos obtenidos.
    */
   public int getPuntos()
   {
    return puntos;
   }
   
   /**
    * dependiendo de que come el personaje 
    * se crea una variable de tipo actor para que 
    * pregunte si es de tipo fake, real , bola de fuego
    * en caso de que sea de alguna de estas clases le resta puntos o 
    * la elimina del escenario.
    */
   public void come()
   {
       Actor actor = getOneObjectAtOffset(2, 1, Words.class);
       Actor actor2 = getOneObjectAtOffset(2, 1, Villano.class);
      
      
        if(actor != null) 
        {
            setImage("images/pou_comiendo.png");
            
            if( actor instanceof Fake) 
            {
                if(puntos > 0 && puntos > 10) puntos -= 10;
                else if(puntos > 0 && puntos < 10) puntos = 0;
                if(!sonido2.isPlaying()) sonido2.play();
            } 
            else if( actor instanceof Real) 
            {
                puntos += 10;
                if(!sonido1.isPlaying()) sonido1.play();
            }
 
            getWorld().removeObject(actor);
            
        } else {
           setImage("images/pue_c.png");
        }
        
        if(actor2 != null) 
        {
            if( actor2 instanceof Boladefuego)
            {
                if(puntos > 0 && puntos > 3) puntos -= 3;
                else if(puntos > 0 && puntos < 3) puntos = 0;
                
                if(!sonido3.isPlaying()) sonido3.play();
            }

            getWorld().removeObject(actor2);
        }
        
        super.setPuntaje(puntos);
  }
}
